//
//  RecorderBindings.h
//  Recorder
//
//  Created by Ashish Dash on 8/20/13.
//  Copyright (c) 2013 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AWSRuntime/AWSRuntime.h>
#import <AWSS3/AWSS3.h>

@interface Recorder : NSObject <AVAudioRecorderDelegate, AVAudioPlayerDelegate>{
@private
    NSURL *recordedFile;
    NSURL *outputFileURL;
}

+ (Recorder*) sharedInstance;

-(void) prepareToRecord:(NSString*)fileName;
-(void) startRecording;
-(void) stopRecording;
-(void) pauseRecording;
-(void) purgeRecorded;
-(void) playRecording;
-(void) playRemoteAudioFile:(NSString*)remoteFileURL;//S3File URL goes here
-(void) pausePlaying;
-(void) stopPlaying;
-(Boolean) audioPlayerDidFinishPlaying;
-(void) uploadRecorded;
-(NSString*)getLastUploadedS3URL;
-(void)uploadImageToS3:(NSString*)imgBase64String:(NSString*)fileNameBCCard;
-(NSString*)getLastUploadedImageS3URL:(NSString*)fileNameBCCard;
-(void)uploadRecordedLeadVN;


@property (nonatomic, retain) AmazonS3Client *s3;

@end
 