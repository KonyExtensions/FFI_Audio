//
//  RecorderBindings.h
//  Recorder
//
//  Created by Ashish Dash on 8/20/13.
//  Copyright (c) 2013 Kony. All rights reserved.
//

#import "RecorderBindings.h"
#import "Recorder.h"

@implementation RecorderBindings

+ (void) prepareToRecord:(NSString*)fileName
{
    [[Recorder sharedInstance] prepareToRecord:(NSString*)fileName];
}
+ (void) startRecording
{
    [[Recorder sharedInstance] startRecording];
}
+ (void) stopRecording
{
    [[Recorder sharedInstance] stopRecording];
}
+ (void) pauseRecording
{
    [[Recorder sharedInstance] pauseRecording];
}
+ (void) purgeRecorded
{
    [[Recorder sharedInstance] purgeRecorded];
}
+ (void) playRecording
{
    [[Recorder sharedInstance] playRecording];
}
//Play remote audio files from S3
+ (void) playRemoteAudioFile:(NSString*)remoteFileURL{
    [[Recorder sharedInstance] playRemoteAudioFile:(NSString*)remoteFileURL];
}
//Pause the playing recorder
+ (void) pausePlaying{
    [[Recorder sharedInstance] pausePlaying];
}

+ (void) stopPlaying{
    [[Recorder sharedInstance] stopPlaying];
}
//After finish playing it will intemate the client
+ (Boolean) audioPlayerDidFinishPlaying{
    [[Recorder sharedInstance] audioPlayerDidFinishPlaying];
}
//S3 upload impl binding
+ (void) uploadRecorded
{
    [[Recorder sharedInstance]uploadRecorded];
}
+ (NSString*)getLastUploadedS3URL{
    [[Recorder sharedInstance] getLastUploadedS3URL];
}
+ (void)uploadImageToS3:(NSString*)imgBase64String:(NSString*)fileNameBCCard{
    [[Recorder sharedInstance] uploadImageToS3:(NSString*)imgBase64String:(NSString*)fileNameBCCard];
}
+ (NSString*)getLastUploadedImageS3URL:(NSString*)fileNameBCCard{
    [[Recorder sharedInstance] getLastUploadedImageS3URL:(NSString*)fileNameBCCard];
}
+ (void)uploadRecordedLeadVN{
    [[Recorder sharedInstance] uploadRecordedLeadVN];
}

@end
