//
//  S3Constants.m
//  AudioDemo
//
//  Created by Ashish Dash on 8/21/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import "S3Constants.h"

@implementation S3Constants

+(NSString *)voiceBucket{
    return [[NSString stringWithFormat:@"%@", CRM_BUCKET] lowercaseString];
}
+(NSString *)leadBucket{
    return [[NSString stringWithFormat:@"%@", LEAD_BUCKET] lowercaseString];
}
@end
