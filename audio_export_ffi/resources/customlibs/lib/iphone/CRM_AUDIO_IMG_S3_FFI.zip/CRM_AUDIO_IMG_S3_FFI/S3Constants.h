//
//  S3Constants.h
//  AudioDemo
//
//  Created by Ashish Dash on 8/21/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//


@interface S3Constants : NSObject

// Constants used to represent your AWS Credentials.
#define ACCESS_KEY_ID          @"AKIAJZZRRBUOVZVQY26Q"
#define SECRET_KEY             @"u4f3c8M9Y7kwqwqw+nj85L0uTMyUid+o4y8lyia1"


// Constants for the Bucket and Object name.
#define CRM_BUCKET                 @"konycrm-dev.konycloud.com"
#define LEAD_BUCKET                @"konycrm-dev.konycloud.com"
#define CREDENTIALS_ERROR_TITLE    @"Missing Credentials"
#define CREDENTIALS_ERROR_MESSAGE  @"AWS Credentials not configured correctly.  Please review the README file."

/**
 * Utility method to Set the bucket name using the Access Key Id.  This will help ensure uniqueness.
 */
+(NSString *)voiceBucket;
+(NSString *)leadBucket;
@end
