//
//  RecorderBindings.h
//  Recorder
//
//  Created by Ashish Dash on 8/20/13.
//  Copyright (c) 2013 Kony. All rights reserved.
//

#import "Recorder.h"

#import "S3Constants.h"
#import <AWSS3/AWSS3.h>
#import <AWSRuntime/AWSRuntime.h>

static Recorder *sharedInstance = nil;


@interface Recorder () {
    AVAudioRecorder *recorder;
    AVAudioPlayer *player;
    
}

@end

@implementation Recorder

@synthesize s3 = _s3;

+ (Recorder*) sharedInstance
{
    if (!sharedInstance) {
        sharedInstance = [[Recorder alloc] init];
    }
    
    return sharedInstance;
}

- (void) prepareToRecord:(NSString*)fileName
{
    NSArray *pathComponents = [NSArray arrayWithObjects:
                               [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject], fileName, nil];
    outputFileURL = [NSURL fileURLWithPathComponents:pathComponents];

    NSLog(@"The file location is at '%@'", outputFileURL.path);

    
    // Setup audio session
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    
   /* //////////////////////ensure other audio is not playing start//////////////
    UInt32 otherAudioIsPlaying;                                   // 1
    UInt32 propertySize = sizeof (otherAudioIsPlaying);
    
    AudioSessionGetProperty (                                     // 2
                             kAudioSessionProperty_OtherAudioIsPlaying,
                             &propertySize,
                             &otherAudioIsPlaying
                             );
    
    if (otherAudioIsPlaying) {                                    // 3
        [[AVAudioSession sharedInstance]
         setCategory: AVAudioSessionCategoryAmbient
         error: nil];
    } else {
        [[AVAudioSession sharedInstance]
         setCategory: AVAudioSessionCategorySoloAmbient
         error: nil];
    }
    ////////////////////////ensure other audio is not playing end////////////////*/
    
    
    ///////////////////Audio Routing to speaker start//////////////////////////////
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;  // 1
    
    AudioSessionSetProperty (
                             kAudioSessionProperty_OverrideAudioRoute,                         // 2
                             sizeof (audioRouteOverride),                                      // 3
                             &audioRouteOverride                                               // 4
    );

    //////////////////////////////Audio Routing to speaker end///////////////////////
    
   // [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];//Tried for speaker
    
    // Define the recorder setting
    NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
    
    [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
    [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
    [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
    [recordSetting setValue:[NSNumber numberWithInt: AVAudioQualityMax] forKey:AVEncoderAudioQualityKey];
    
    // Initiate and prepare the recorder
    recorder = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:NULL];
    recorder.delegate = self;
    recorder.meteringEnabled = YES;
    [recorder prepareToRecord];
}
-(void) startRecording
{
    //Stop if it is playing anything
    if (player.playing) {
        [player stop];
    }
    //Start recording if it is not doing it already
    if (!recorder.recording) {
        AVAudioSession *session = [AVAudioSession sharedInstance];
        [session setActive:YES error:nil];
        // Start recording
        [recorder record];
    }
}
-(void) stopRecording
{
    [recorder stop];
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setActive:NO error:nil];
}
-(void) pauseRecording
{
    if (player.playing) {
        [player stop];
    }
    
    if (recorder.recording) {
        [recorder pause];
    }
}
-(void) purgeRecorded
{
    // For error information
    NSError *error;
    
    // Create file manager
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    
    // Point to Document directory
    NSString *documentsDirectory = [NSHomeDirectory()
                                    stringByAppendingPathComponent:@"Documents"];
   
    // Attempt to delete the file at outputFileURL.path
    if ([fileMgr removeItemAtPath:outputFileURL.path error:&error] != YES)
        NSLog(@"Unable to delete file: %@", [error localizedDescription]);
    
    // Show contents of Documents directory
    NSLog(@"Documents directory: %@",
          [fileMgr contentsOfDirectoryAtPath:documentsDirectory error:&error]);
    
}
-(void) playRecording
{
    if (!recorder.recording){
        
        player = [[AVAudioPlayer alloc] initWithContentsOfURL:recorder.url error:nil];
        [player setDelegate:self];
        [player play];
    }
}

-(void) playRemoteAudioFile:(NSString*)remoteFileURL{
    
    NSURL *url = [NSURL URLWithString:remoteFileURL];
    NSData *soundData = [NSData dataWithContentsOfURL:url];
    player = [[AVAudioPlayer alloc] initWithData:soundData  error:NULL];
    player.delegate = self;
    [player play];
}
-(void) pausePlaying{
    if (player.playing) {
        [player pause];
    }
}
-(void) stopPlaying{
    if (player.playing) {
        [player stop];
    }
}

- (void) audioRecorderDidFinishRecording:(AVAudioRecorder *)avrecorder successfully:(BOOL)flag{
    
    
}
- (Boolean) audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Done"
                                                    message: @"Finish playing the recording!"
                                                   delegate: nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    
    //[alert show];
    return true;
}

//S3 upload implementation
- (void)uploadRecorded{
    //Logic for S3 upload goes here
    NSLog(@"For S3 the file is at '%@'", outputFileURL.path);
    // Initial the S3 Client.
    self.s3 = [[[AmazonS3Client alloc] initWithAccessKey:ACCESS_KEY_ID withSecretKey:SECRET_KEY] autorelease];
    self.s3.endpoint = [AmazonEndpoints s3Endpoint:@"konycrmfiles-dev.konycloud.com.s3-website-us-east-1.amazonaws.com"];
    NSData *voiceDataFile=[NSData dataWithContentsOfFile:outputFileURL.path];
   
    NSString *voiceFileName=outputFileURL.lastPathComponent;
    
    // Upload file data.  Remember to set the content type.
    S3PutObjectRequest *por = [[[S3PutObjectRequest alloc] initWithKey:voiceFileName
                                                              inBucket:[S3Constants voiceBucket]] autorelease];
    //por.contentType = @"image/jpeg";
    por.contentType = @"video/mp4";
    por.data = voiceDataFile;
    por.delegate = self;
    
    // Put the file data into the specified s3 bucket and object.
    [self.s3 putObject:por];
    
}
//S3 upload implementation
- (void)uploadRecordedLeadVN{
    //Logic for S3 upload goes here
    NSLog(@"For S3 the file is at '%@'", outputFileURL.path);
   
    // Initial the S3 Client.
    self.s3 = [[[AmazonS3Client alloc] initWithAccessKey:ACCESS_KEY_ID withSecretKey:SECRET_KEY] autorelease];
    self.s3.endpoint = [AmazonEndpoints s3Endpoint:@"konycrmlead-dev.konycloud.com.s3-website-us-east-1.amazonaws.com"];
    
    NSData *voiceDataFile=[NSData dataWithContentsOfFile:outputFileURL.path];
    NSString *voiceFileName=outputFileURL.lastPathComponent;
    
    // Upload file data.  Remember to set the content type.
    S3PutObjectRequest *por = [[[S3PutObjectRequest alloc] initWithKey:voiceFileName
                                                              inBucket:[S3Constants voiceBucket]] autorelease];
    por.contentType = @"video/mp4";
    por.data = voiceDataFile;
    por.delegate = self;
    
    // Put the file data into the specified s3 bucket and object.
    [self.s3 putObject:por];
}
//S3 upload image implementation
- (void)uploadImageToS3:(NSString*)imgBase64String : (NSString*)fileNameBCCard{
    //Logic for S3 upload goes here
   
    // Init the S3 Client.
    self.s3 = [[[AmazonS3Client alloc] initWithAccessKey:ACCESS_KEY_ID withSecretKey:SECRET_KEY] autorelease];
    self.s3.endpoint = [AmazonEndpoints s3Endpoint:@"konycrmlead-dev.konycloud.com.s3-website-us-east-1.amazonaws.com"];
    
    NSData *imgDataFile=[NSData dataWithBase64EncodedString:imgBase64String];
    
    NSString *imgFileName=fileNameBCCard;
    
    // Upload file data.  Remember to set the content type.
    S3PutObjectRequest *por = [[[S3PutObjectRequest alloc] initWithKey:imgFileName
                                                              inBucket:[S3Constants voiceBucket]] autorelease];
    por.contentType = @"image/jpeg";
    //por.contentType = @"video/mp4";
    por.data = imgDataFile;
    por.delegate = self;
    
    // Put the file data into the specified s3 bucket and object.
    [self.s3 putObject:por];
}

-(NSString*)getLastUploadedS3URL{
    // Get the URL
    // Set the content type so that the browser will treat the URL as an image.
    S3ResponseHeaderOverrides *override = [[[S3ResponseHeaderOverrides alloc] init] autorelease];
    //override.contentType = @"image/jpeg";
    override.contentType = @"video/mp4";
    
    // Request a pre-signed URL to picture that has been uplaoded.
    S3GetPreSignedURLRequest *gpsur = [[[S3GetPreSignedURLRequest alloc] init] autorelease];
    gpsur.key                     = outputFileURL.lastPathComponent;
    gpsur.bucket                  = [S3Constants voiceBucket];
    gpsur.expires                 = [NSDate dateWithTimeIntervalSinceNow:(NSTimeInterval) 157680000]; // Added a 5 years worth of seconds to the current time.
    gpsur.responseHeaderOverrides = override;
    
    
    
    NSError *error;
    NSURL *url = [self.s3 getPreSignedURL:gpsur error:&error];
    
    if(url == nil)
    {
        if(error != nil)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                NSLog(@"Error: %@", error);
                [self showAlertMessage:[error.userInfo objectForKey:@"message"] withTitle:@"Browser Error"];
            });
        }
        return @"";
    }
    else{
        NSLog(@"The file location in S3 bucket is : '%@'", url.absoluteString);
        return url.absoluteString;
    }
    
}


-(NSString*)getLastUploadedImageS3URL: (NSString*)fileNameBCCard{
    // Get the URL
    // Set the content type so that the browser will treat the URL as an image.
    S3ResponseHeaderOverrides *override = [[[S3ResponseHeaderOverrides alloc] init] autorelease];
    override.contentType = @"image/jpeg";

    // Request a pre-signed URL to picture that has been uplaoded.
    S3GetPreSignedURLRequest *gpsur = [[[S3GetPreSignedURLRequest alloc] init] autorelease];
    gpsur.key                     = fileNameBCCard;
    gpsur.bucket                  = [S3Constants leadBucket];
    gpsur.expires                 = [NSDate dateWithTimeIntervalSinceNow:(NSTimeInterval) 157680000]; // Added a 5 years worth of seconds to the current time.
    gpsur.responseHeaderOverrides = override;
  
    
    
    NSError *error;
    NSURL *url = [self.s3 getPreSignedURL:gpsur error:&error];
    
    if(url == nil)
    {
        if(error != nil)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                
                NSLog(@"Error: %@", error);
                [self showAlertMessage:[error.userInfo objectForKey:@"message"] withTitle:@"Browser Error"];
            });
        }
        return @"";
    }
    else{
        NSLog(@"The file location in S3 bucket is : '%@'", url.absoluteString);
        return url.absoluteString;
    }

}

//- (void)processBackgroundThreadUploadInBackground:(NSData *)voiceDataFile
//{
//    // Upload image data.  Remember to set the content type.
//    S3PutObjectRequest *por = [[[S3PutObjectRequest alloc] initWithKey:VOICE_FILE_NAME
//                                                              inBucket:[S3Constants voiceBucket]] autorelease];
//    //por.contentType = @"image/jpeg";
//    por.contentType = @"video/mp4";
//    //por.data        = voiceDataFile;
//    por.data = recorder.url;
//    // Put the image data into the specified s3 bucket and object.
//    S3PutObjectResponse *putObjectResponse = [self.s3 putObject:por];
//    [self performSelectorOnMainThread:@selector(showCheckErrorMessage:)
//                           withObject:putObjectResponse.error
//                        waitUntilDone:NO];
//}
//- (void)processDelegateUpload:(NSData *)imageData
//{
//    // Upload image data.  Remember to set the content type.
//    S3PutObjectRequest *por = [[[S3PutObjectRequest alloc] initWithKey:VOICE_FILE_NAME
//                                                              inBucket:[S3Constants voiceBucket]] autorelease];
//    //por.contentType = @"image/jpeg";
//    por.contentType = @"video/mp4";
//    por.data = imageData;
//    por.delegate = self;
//    
//    // Put the image data into the specified s3 bucket and object.
//    [self.s3 putObject:por];
//}

- (void)showCheckErrorMessage:(NSError *)error
{
    if(error != nil)
    {
        NSLog(@"Error: %@", error);
        [self showAlertMessage:[error.userInfo objectForKey:@"message"] withTitle:@"Upload Error, Please try once more."];
    }
    else
    {
        [self showAlertMessage:@"The note was successfully uploaded." withTitle:@"Upload Completed"];
    }
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
#pragma mark - Show the image in the browser

-(IBAction)showInBrowser:(id)sender
{
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        
        // Set the content type so that the browser will treat the URL as an image.
        S3ResponseHeaderOverrides *override = [[[S3ResponseHeaderOverrides alloc] init] autorelease];
        //override.contentType = @"image/jpeg";
        override.contentType = @"video/mp4";

        
        // Request a pre-signed URL to picture that has been uplaoded.
        S3GetPreSignedURLRequest *gpsur = [[[S3GetPreSignedURLRequest alloc] init] autorelease];
        gpsur.key                     = outputFileURL.lastPathComponent;
        gpsur.bucket                  = [S3Constants voiceBucket];
        gpsur.expires                 = [NSDate dateWithTimeIntervalSinceNow:(NSTimeInterval) 3600]; // Added an hour's worth of seconds to the current time.
        gpsur.responseHeaderOverrides = override;
        
        // Get the URL
        NSError *error;
        NSURL *url = [self.s3 getPreSignedURL:gpsur error:&error];
        
        if(url == nil)
        {
            if(error != nil)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    NSLog(@"Error: %@", error);
                    [self showAlertMessage:[error.userInfo objectForKey:@"message"] withTitle:@"Browser Error"];
                });
            }
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                // Display the URL in Safari
                [[UIApplication sharedApplication] openURL:url];
            });
        }
        
    });
}

@end
