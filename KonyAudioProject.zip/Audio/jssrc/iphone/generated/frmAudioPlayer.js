//Form JS File
function frmAudioPlayer_btnStartRec_onClick_seq0(eventobject) {
    if (frmAudioPlayer.tbFilename.text == null || frmAudioPlayer.tbFilename.text == "") {
        audio.initRecording("a.mp4");
    } else {
        audio.initRecording(frmAudioPlayer.tbFilename.text + ".mp4");
    }
    audio.record();
    frmAudioPlayer.btnStartRec.text = "Record your voice now ...";
};

function frmAudioPlayer_btnStopRec_onClick_seq0(eventobject) {
    audio.stopRecording();
    frmAudioPlayer.btnStartRec.text = "Start Rec";
};

function frmAudioPlayer_btnPlayRec_onClick_seq0(eventobject) {
    audio.playRecorded();
};

function frmAudioPlayer_btnDeleteRec_onClick_seq0(eventobject) {
    audio.purgeRecorded();
};

function frmAudioPlayer_btnPauseRec_onClick_seq0(eventobject) {
    if (!isPaused) {
        audio.pauseRecording();
        frmAudioPlayer.btnPauseRec.text = "Continue Rec";
        isPaused = true;
    } else {
        audio.record();
        frmAudioPlayer.btnPauseRec.text = "Pause Rec";
        isPaused = false;
    }
};

function frmAudioPlayer_btnPlayRemoteAudio_onClick_seq0(eventobject) {
    audio.playRemoteAudioFile(frmAudioPlayer.txtRemoteFileURL.text);
};

function frmAudioPlayer_button1980285908159_onClick_seq0(eventobject) {
    frmAudioPlayer.txtRemoteFileURL.text = "http://www.sample-videos.com/audio/mp3/india-national-anthem.mp3";
};

function frmAudioPlayer_btnStop_onClick_seq0(eventobject) {
    audio.stopPlaying();
};

function addWidgetsfrmAudioPlayer() {
    var btnStartRec = new kony.ui.Button({
        "id": "btnStartRec",
        "top": "51dp",
        "left": "6dp",
        "width": "260dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Start Rec",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnStartRec_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var btnStopRec = new kony.ui.Button({
        "id": "btnStopRec",
        "top": "112dp",
        "left": "7dp",
        "width": "122dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Stop Rec",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnStopRec_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var btnPlayRec = new kony.ui.Button({
        "id": "btnPlayRec",
        "top": "174dp",
        "left": "8dp",
        "width": "260dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Play Recorded",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnPlayRec_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var btnDeleteRec = new kony.ui.Button({
        "id": "btnDeleteRec",
        "top": "234dp",
        "left": "8dp",
        "width": "260dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Delete Recordings",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnDeleteRec_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var tbFilename = new kony.ui.TextBox2({
        "id": "tbFilename",
        "top": "10dp",
        "left": "6dp",
        "width": "260dp",
        "height": "40dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "MyAudioFile1",
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": null,
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "skin": "tbx2Normal",
        "focusSkin": "tbx2Focus"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "containerHeightMode": constants.TEXTBOX_DEFAULT_PLATFORM_HEIGHT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "pasteboardType": constants.TEXTBOX_PASTE_BOARD_TYPE_SYSTEM_LEVEL,
        "leftViewImage": null,
        "showClearButton": true,
        "showProgressIndicator": true,
        "showCloseButton": true,
        "closeButtonText": "Done",
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT,
        "autoCorrect": false
    });
    var btnPauseRec = new kony.ui.Button({
        "id": "btnPauseRec",
        "top": "112dp",
        "left": "136dp",
        "width": "134dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Pause Rec",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnPauseRec_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var txtRemoteFileURL = new kony.ui.TextBox2({
        "id": "txtRemoteFileURL",
        "top": "298dp",
        "left": "7dp",
        "width": "295dp",
        "height": "26dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "http://",
        "secureTextEntry": false,
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "Enter the remote audio file URL",
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "skin": "tbx2Normal",
        "focusSkin": "tbx2Focus"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "containerHeightMode": constants.TEXTBOX_DEFAULT_PLATFORM_HEIGHT,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "pasteboardType": constants.TEXTBOX_PASTE_BOARD_TYPE_SYSTEM_LEVEL,
        "leftViewImage": null,
        "showClearButton": true,
        "showProgressIndicator": true,
        "showCloseButton": true,
        "closeButtonText": "Done",
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT,
        "autoCorrect": false
    });
    var btnPlayRemoteAudio = new kony.ui.Button({
        "id": "btnPlayRemoteAudio",
        "top": "326dp",
        "left": "51dp",
        "width": "125dp",
        "height": "39dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Play Remote Audio File",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnPlayRemoteAudio_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1980285908159 = new kony.ui.Button({
        "id": "button1980285908159",
        "top": "326dp",
        "left": "6dp",
        "width": "44dp",
        "height": "39dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Sample",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_button1980285908159_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var btnStop = new kony.ui.Button({
        "id": "btnStop",
        "top": "326dp",
        "left": "178dp",
        "width": "88dp",
        "height": "39dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Stop Playing",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmAudioPlayer_btnStop_onClick_seq0
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var flexContainer198028590813 = new kony.ui.FlexContainer({
        "id": "flexContainer198028590813",
        "top": "4dp",
        "left": "4dp",
        "width": "96%",
        "height": "446dp",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[4,4]",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    flexContainer198028590813.setDefaultUnit(kony.flex.DP)
    flexContainer198028590813.add(
    btnStartRec, btnStopRec, btnPlayRec, btnDeleteRec, tbFilename, btnPauseRec, txtRemoteFileURL, btnPlayRemoteAudio, button1980285908159, btnStop);
    frmAudioPlayer.add(
    flexContainer198028590813);
};

function frmAudioPlayerGlobals() {
    var MenuId = [];
    frmAudioPlayer = new kony.ui.Form2({
        "id": "frmAudioPlayer",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "frm",
        "bouncesZoom": true,
        "zoomScale": 1.0,
        "minZoomScale": 1.0,
        "maxZoomScale": 1.0,
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmAudioPlayer
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "needsIndicatorDuringPostShow": true,
        "formTransparencyDuringPostShow": "100",
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "configureExtendTop": false,
        "configureExtendBottom": false,
        "configureStatusBarStyle": false,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        }
    });
    frmAudioPlayer.setDefaultUnit(kony.flex.DP);
};